I had included two files, text.java and HomeSecuritySystem.java, the first one is to verify aNumber question, and the second one
is used to answer the system design question. Both files includes whole function and test method, just simply run the code and the
result will be shown on the command line.
